<?php
/* include the class file (global - within application) */
include_once 'classes/class.user.php';
include_once 'classes/class.product.php';
include_once 'classes/class.receive.php';
include_once 'classes/class.release.php';
include_once 'classes/class.inventory.php';
include 'config/config.php';

$user = new User();
$product = new Product();
$receive = new Receive();
$release = new Release();
$inventory = new Inventory();
if (!$user->get_session()) {
    header("location: login.php");
}
$user_email = $_SESSION['user_email'];
$user_id = $user->get_user_id($user_email);

// Retrieve user access level and login ID from the database
$pdo = new PDO("mysql:host=localhost;dbname=db_wbapp", "root", "");
$query = "SELECT user_access, user_id FROM tbl_users WHERE user_email = :email";
$stmt = $pdo->prepare($query);
$stmt->bindParam(':email', $user_email);
$stmt->execute();
$result = $stmt->fetch(PDO::FETCH_ASSOC);

// Assign the values to the variables
$user_access_level = $result['user_access'];
$user_id_login = $result['user_id'];

$page = (isset($_GET['page']) && $_GET['page'] != '') ? $_GET['page'] : '';
$subpage = (isset($_GET['subpage']) && $_GET['subpage'] != '') ? $_GET['subpage'] : '';
$action = (isset($_GET['action']) && $_GET['action'] != '') ? $_GET['action'] : '';
$id = (isset($_GET['id']) && $_GET['id'] != '') ? $_GET['id'] : '';
?>

<!DOCTYPE html>
<html>
<head>
    <meta charset="UTF-8">
    <title>Application</title>
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="css/style.css">
</head>
<body>
<div id="main-nav">
    <nav>
        <h2>SNEAKERHEAD</h2>
        <ul>
            <li><a href="index.php">Home</a></li>
            <li><a href="index.php?page=receive">Receiving</a></li>
            <li><a href="index.php?page=release">Releasing</a></li>
            <li><a href="index.php?page=inventory">Inventory</a></li>
            <li><a href="index.php?page=settings">Set</a></li>
            <li><a href="xlsx-user-report.php">Download User Report (Excel)</a></li>
            <li><a href="generate_user_excel.php">Generate User Report (PDF)</a></li>
            <li class="move-right"><a href="logout.php">Log Out</a></li>
            <li class="move-right"><?php //echo $user->get_user_lastname($user_id).', '.$user->get_user_firstname($user_id);?>&nbsp;&nbsp; &nbsp;&nbsp; &nbsp;&nbsp;</li>
        </ul>
    </nav>
</div>

<div id="container">
    <div id="wrapper">
        <div id="content">
            <?php
            switch ($page) {
                case 'settings':
                    require_once 'settings-module/index.php';
                    break;
                case 'inventory':
                    require_once 'inventory-module/index.php';
                    break;
                case 'receive':
                    require_once 'receive-module/index.php';
                    break;
                case 'release':
                    require_once 'release-module/index.php';
                    break;
                default:
                    require_once 'main.php';
                    break;
            }
            ?>
        </div>
    </div>
</div>

</body>
</html>
