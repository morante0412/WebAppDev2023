<div id="second-submenu">
  <nav>
    <ul>
      <li><a href="index.php?page=settings&subpage=users">Users</a></li>
      <li><a href="index.php?page=settings&subpage=products">Products</a></li>
    </ul>
  </nav>
</div>
<div id="content">
  <?php
    switch($subpage){
      case 'users':
        require_once 'users-module/index.php';
        break; 
      case 'products':
        require_once 'products-module/index.php';
        break; 
      case 'module_xxx':
        require_once 'module-folder/';
        break; 
      default:
        require_once 'main.php';
        break; 
    }
  ?>
</div>