| <a href="xlsx-user-report.php">Download User Report (Excel)</a> |
<a href="generate_user_excel.php">Generate User Report (PDF)</a> |