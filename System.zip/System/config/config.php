<?php
date_default_timezone_set("Asia/Manila");
	session_start();
	define('DB_SERVER','localhost');
	define('DB_USERNAME','root');
	define('DB_PASSWORD','');
	define('DB_DATABASE','db_wbapp');
?>